===========================================
 ``celery.backends.elasticsearch``
===========================================

.. contents::
    :local:
.. currentmodule:: celery.backends.elasticsearch

.. automodule:: celery.backends.elasticsearch
    :members:
    :undoc-members:
