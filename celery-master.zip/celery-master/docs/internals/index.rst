.. _internals:

===========
 Internals
===========

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 2

    guide
    deprecation
    worker
    protocol
    app-overview
    reference/index
