==================================================
 ``celery.worker.consumer.tasks``
==================================================

.. contents::
    :local:
.. currentmodule:: celery.worker.consumer.tasks

.. automodule:: celery.worker.consumer.tasks
    :members:
    :undoc-members:
