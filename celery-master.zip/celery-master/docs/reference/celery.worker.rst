========================================
 ``celery.worker``
========================================

.. contents::
    :local:
.. currentmodule:: celery.worker

.. automodule:: celery.worker
    :members:
    :undoc-members:
